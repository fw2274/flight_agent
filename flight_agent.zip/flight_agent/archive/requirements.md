# need to add an agent to understand user request
# eg. translate the request of "Find a round-trip flight from ATL to JFK in Dec 02 and return on Dec 15 for 2 adults in economy class" intelligently
# i.e. IATA code to match NYC to near by airport code 
# if Christmas is mentioned, translate that to the departure and return date


Possible Causes
The model isn't extracting parameters correctly from the natural language query
The tool schema might not be clear enough for the model to understand what parameters are needed
The query format might need to be more explicit about airport codes
